<!-- CARD -->
START
Basic
This is a test.
Back: Test successful!
Tags: Tag1 Tag2 Tag3
END

<!-- CARD -->
START
Basic
This is a test. This should not have any tags except default ones.
And the test is continuing.
Back: Test successful!
END

<!-- CARD -->
START
Basic
This is a test. this should have meow-tag
And the test is continuing. #meow
Back: Test successful!
END
