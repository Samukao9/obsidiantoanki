FILE TAGS: Maths School Physics

<!-- CARD -->
START
Basic
This is a test with file tags specified inline
Back: Test successful!
END


<!-- CARD -->
START
Basic
This is a test 2 with file tags specified inline
And the test is continuing.
Back: Test successful!
END
