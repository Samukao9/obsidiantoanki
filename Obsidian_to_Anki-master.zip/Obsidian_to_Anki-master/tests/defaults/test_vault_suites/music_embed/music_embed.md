<!-- CARD -->
START
Basic
This is a test with music
![[test.mp3]]
Back: Test successful!
END
