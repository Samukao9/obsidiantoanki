<!-- CARD -->

In Neuracache style, to make a flashcard you do #flashcard
The next lines then become the back of the flashcard

<!-- CARD -->

If you want, it's certainly possible to
do a multi-line question #flashcard
You just need to make sure both
the question and answer are one paragraph.

<!-- CARD -->

And, of course #flashcard


Whitespace is ignored!
