<!-- CARD -->
START
Basic
Inline $x = 5$
Back: Test successful!
END

<!-- CARD -->
START
Basic
Displayed $$z = 10$$
Back: Test successful!
END
