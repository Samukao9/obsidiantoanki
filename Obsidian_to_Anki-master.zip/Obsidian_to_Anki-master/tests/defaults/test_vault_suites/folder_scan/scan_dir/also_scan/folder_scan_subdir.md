<!-- CARD -->
# Style Subdir 
This style is suitable for having the header as the front, and the answer as the back
# Overall heading Subdir
<!-- CARD -->
## Subheading 1 Subdir
You're allowed to nest headers within each other
<!-- CARD -->
## Subheading 2 Subdir
It'll take the deepest level for the question
<!-- CARD -->
## Subheading 3 Subdir
   
   
   
It'll even
Span over
Multiple lines, and ignore preceding whitespace