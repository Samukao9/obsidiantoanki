
# Style snsmd
This style is suitable for having the header as the front, and the answer as the back
# Overall heading

## Subheading 1 snsmd

You're allowed to nest headers within each other

## Subheading 2 snsmd

It'll take the deepest level for the question

## Subheading 3 snsmd


   
It'll even
Span over
Multiple lines, and ignore preceding whitespace
