<!-- CARD -->
START
Cloze

Do ![alt-text](http://meow.in/meow.png). You'll want to do 'copy image address' on the image, and use that for the image url.

END



