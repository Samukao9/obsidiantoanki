TARGET DECK: MathematicsInSameLine

<!-- CARD -->
START
Basic
This is a test with target deck in a same line.
Back: Test successful!
END