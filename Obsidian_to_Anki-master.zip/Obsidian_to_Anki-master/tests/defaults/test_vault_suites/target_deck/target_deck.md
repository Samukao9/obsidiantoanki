TARGET DECK
MathematicsInNextLine

<!-- CARD -->
START
Basic
This is a test with target deck in a seperate line.
Back: Test successful!
END