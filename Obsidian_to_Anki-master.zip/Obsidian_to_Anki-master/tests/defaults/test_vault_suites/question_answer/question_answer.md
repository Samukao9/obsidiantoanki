

<!-- CARD -->
Q: How do you use this style?
A: Just like this.

<!-- CARD -->
Q: Can the question
run over multiple lines?
A: Yes, and
So can the answer

<!-- CARD -->
Q: Does the answer need to be immediately after the question?


A: No, and preceding whitespace will be ignored.

<!-- CARD -->
Q: How is this possible?
A: The 'magic' of regular expressions!

<!-- CARD -->
Q: How is this possible? #tag2
A: The 'magic' of regular expressions! #tag1