<!-- CARD -->
START
Cloze

This is a {{c1::cloze note}}

END

<!-- CARD -->
<!-- - This is a {{c1::cloze}} note with {{c2::two clozes}} -->
START
Cloze

This is a {cloze} note with {two clozes}

END

<!-- CARD -->
<!-- - This is a {{c2::cloze}} note with {{c1::id syntax}} -->
START
Cloze

This is a {2:cloze} note with {1:id syntax}

END

<!-- CARD -->
<!-- - This is a {{c2::cloze}} {{c3::note}} with {{c1::alternate id syntax}} -->
START
Cloze

This is a {2|cloze} {3|note} with {1|alternate id syntax} 

END

<!-- CARD -->
<!-- - This is a {{c1::cloze}} note with {{c2::another}} type of {{c3::id syntax}} -->
START
Cloze

This is a {c1:cloze} note with {c2:another} type of {c3:id syntax} 

END

<!-- CARD -->
<!-- - This is a {{c1::cloze}} note with {{c2::yet another}} type of {{c3::id syntax}} -->
START
Cloze

This is a {c1|cloze} note with {c2|yet another} type of {c3|id syntax} 

END

<!-- CARD -->
<!-- - This is a {{c1::cloze}} note with {{c2::multiple}} non-id clozes, as well as {{c2::some clozes}} with {{c1::other styles}} -->
START
Cloze

This is a {cloze} note with {multiple} non-id clozes, as well as {2:some clozes} with {c1|other styles} 

END

