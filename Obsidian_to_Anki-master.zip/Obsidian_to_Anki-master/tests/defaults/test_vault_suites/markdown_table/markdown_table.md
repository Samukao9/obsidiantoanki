<!-- CARD -->
| How do you use this style? |
| ---- |
| Just like this |

Of course, the script will ignore anything outside a table.

| Furthermore, the script | should also |
| ----- | ----- |
| Ignore any tables | with more than one column |

<!-- CARD -->
| Why might this style be useful? |
| --------- |
| It looks nice when rendered as HTML in a markdown editor. |
