<!-- CARD -->
START
Basic
This is a test. Should be in Science deck
Back: Test successful!
END

