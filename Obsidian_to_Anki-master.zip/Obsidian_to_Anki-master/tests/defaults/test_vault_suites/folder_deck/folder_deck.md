<!-- CARD -->
START
Basic
This is a test. Should be in Default deck.
Back: Test successful!
END
