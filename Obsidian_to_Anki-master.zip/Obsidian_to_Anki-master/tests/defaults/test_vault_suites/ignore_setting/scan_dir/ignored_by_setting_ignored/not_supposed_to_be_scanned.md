<!-- NOT A CARD BECAUSE ITS IGNORED -->
START
Basic
This is a test. Parent dir is ignored.
Back: Test successful!
Tags: Testing
END

<!-- NOT A CARD BECAUSE ITS IGNORED -->
START
Basic
Front: This is a test with Front specified. Parent dir is ignored.
Back: Test successful!
Tags: Testing 2
END

<!-- NOT A CARD BECAUSE ITS IGNORED -->
START
Basic
This is a test. Parent dir is ignored.
And the test is continuing.
Back: Test successful!
END