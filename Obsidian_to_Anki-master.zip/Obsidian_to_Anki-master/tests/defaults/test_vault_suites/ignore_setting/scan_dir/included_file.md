
<!-- CARD -->
START
Basic
This is a test. This file should be scanned for cards as it is in the scandir and not ignored.
Back: Test successful!
Tags: Testing
END

<!-- CARD -->
START
Basic
Front: This is a test with Front specified. This file should be scanned for cards as it is in the scandir and not ignored.
Back: Test successful!
Tags: Testing 2
END

<!-- CARD -->
START
Basic
This is a test. This file should be scanned for cards as it is in the scandir and not ignored.
And the test is continuing.
Back: Test successful!
END
