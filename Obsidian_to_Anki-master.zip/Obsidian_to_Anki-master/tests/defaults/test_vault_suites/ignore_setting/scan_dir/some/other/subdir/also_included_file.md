
<!-- CARD -->
START
Basic
This is a test. Subfolders should be scanned for cards.
Back: Test successful!
Tags: Testing
END

<!-- CARD -->
START
Basic
Front: This is a test with Front specified. Subfolders should be scanned for cards.
Back: Test successful!
Tags: Testing 2
END

<!-- CARD -->
START
Basic
This is a test. Subfolders should be scanned for cards.
And the test is continuing.
Back: Test successful!
END
