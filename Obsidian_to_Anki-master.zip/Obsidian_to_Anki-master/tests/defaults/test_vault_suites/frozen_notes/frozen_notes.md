

FROZEN - Basic:
Front: <br/>What is the country's capital?

<!-- CARD -->
START
Basic
India (This is a Test)

Back: Delhi! Test successful!
END

