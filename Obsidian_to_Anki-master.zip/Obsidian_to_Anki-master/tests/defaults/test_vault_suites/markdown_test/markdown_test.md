<!-- CARD -->
START
Basic
This note showcases a bunch of different markdown formatting.  
You can use *italics* or _italics_.
**Bold** or __Bold__
If you want to strongly emphasise, just **_do_** __*both*__
# Headers are supported too
## At
### Varying
#### Levels

1. You can get
2. Ordered lists
3. By doing numbers like this

* Unordered lists
* work like this.
* Make sure to leave a gap between lists and other things

Back: A few more elements to see.
You can include [links](https://www.wikipedia.org/) to websites.
`Code blocks` are supported
Github-flavoured code blocks too, but Anki won't do syntax highlighting
```python
    print("Hello world!")
```
Tables should hopefully work:

First Header  | Second Header
------------- | -------------
Content Cell  | Content Cell
Content Cell  | Content Cell

Tags: Way_too_much_info
END
