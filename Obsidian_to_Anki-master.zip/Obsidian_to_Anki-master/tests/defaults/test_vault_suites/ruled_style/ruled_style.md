

<!-- CARD -->

How do you use ruled style?
---
You need at least three '-' between the front and back of the card.


<!-- CARD -->

Are paragraphs
supported?
---------
Yes, but you need the front and back
directly before and after the ruler.