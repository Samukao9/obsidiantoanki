

<!-- CARD -->
This is how to use::Remnote single-line style
The script won't see things outside of it.
<!-- CARD -->
You can have::multiple notes in the same file