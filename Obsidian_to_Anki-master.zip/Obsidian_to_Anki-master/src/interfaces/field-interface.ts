export type FIELDS_DICT = Record<string, string[]>

export type FROZEN_FIELDS_DICT = Record<string, Record<string, string>>
