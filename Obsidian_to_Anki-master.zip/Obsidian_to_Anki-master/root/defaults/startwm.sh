#!/bin/bash
/startpulse.sh &
/usr/bin/openbox-session > /dev/null 2>&1
